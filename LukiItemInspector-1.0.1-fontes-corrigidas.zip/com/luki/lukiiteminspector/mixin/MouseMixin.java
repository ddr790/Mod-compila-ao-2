package com.luki.lukiiteminspector.mixin;

import com.luki.lukiiteminspector.client.InspectState;
import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Captures raw mouse movement for item rotation and the scroll wheel for zoom,
 * cancelling the normal in-game effects (scrolling hotbar, zooming) while inspecting.
 */
@Mixin(MouseHandler.class)
public abstract class MouseMixin {
    @Shadow private double accumulatedDX;
    @Shadow private double accumulatedDY;

    @Inject(method = "turnPlayer", at = @At("HEAD"), cancellable = true)
    private void luki$captureRotation(CallbackInfo ci) {
        InspectState state = InspectState.INSTANCE;
        if (!state.inspecting) return;

        double dx = accumulatedDX;
        double dy = accumulatedDY;
        if (dx != 0.0 || dy != 0.0) {
            float sens = (float) (com.luki.lukiiteminspector.client.LukiItemInspectorClient.CONFIG.rotationSensitivity / 200.0);
            state.rotY += (float) (dx * sens);
            state.rotX += (float) (dy * sens);
            state.rotX = Math.max(-135.0f, Math.min(135.0f, state.rotX));
        }
        accumulatedDX = 0.0;
        accumulatedDY = 0.0;
        ci.cancel();
    }

    @Inject(method = "onScroll(JDD)V", at = @At("HEAD"), cancellable = true)
    private void luki$captureScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
        InspectState state = InspectState.INSTANCE;
        if (!state.inspecting) return;

        if (vertical != 0.0) {
            var cfg = com.luki.lukiiteminspector.client.LukiItemInspectorClient.CONFIG;
            state.zoom += (float) (vertical * 0.1);
            state.zoom = Math.max(cfg.minZoom, Math.min(cfg.maxZoom, state.zoom));
        }
        ci.cancel();
    }
}
