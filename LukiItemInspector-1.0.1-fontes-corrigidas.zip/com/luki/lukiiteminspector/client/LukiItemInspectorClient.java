package com.luki.lukiiteminspector.client;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.common.MinecraftForge;
import com.mojang.blaze3d.platform.InputConstants;
import org.lwjgl.glfw.GLFW;

public final class LukiItemInspectorClient {
    public static InspectConfig CONFIG;
    public static KeyMapping inspectKey;
    public static KeyMapping resetKey;

    public static void initialize(IEventBus modEventBus) {
        CONFIG = InspectConfig.load();
        modEventBus.addListener(LukiItemInspectorClient::registerKeyMappings);
        MinecraftForge.EVENT_BUS.addListener(LukiItemInspectorClient::onClientTick);
    }

    private static void registerKeyMappings(RegisterKeyMappingsEvent event) {
        inspectKey = new KeyMapping("key.lukiiteminspector.inspect",
                InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, "category.lukiiteminspector");
        resetKey = new KeyMapping("key.lukiiteminspector.reset",
                InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_R, "category.lukiiteminspector");
        event.register(inspectKey);
        event.register(resetKey);
    }

    private static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }

        InspectState state = InspectState.INSTANCE;
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null) {
            state.stop();
            return;
        }

        if (state.inspecting) {
            if (minecraft.player.getMainHandItem().isEmpty()
                    && minecraft.player.getOffhandItem().isEmpty()) {
                state.inspecting = false;
                return;
            }
            if (resetKey.consumeClick()) {
                state.resetPose();
            }

            float smooth = 0.25f;
            state.smoothRotX += (state.rotX - state.smoothRotX) * smooth;
            state.smoothRotY += (state.rotY - state.smoothRotY) * smooth;
        }

        while (inspectKey.consumeClick()) {
            state.inspecting = !state.inspecting;
            state.resetPose();
            if (state.inspecting) {
                state.progress = 0.0f;
            }
        }

        float speed = CONFIG.animationSpeed * 0.12f;
        if (state.inspecting && state.progress < 1.0f) {
            state.progress = Math.min(1.0f, state.progress + speed);
        } else if (!state.inspecting && state.progress > 0.0f) {
            state.progress = Math.max(0.0f, state.progress - speed);
        }
    }
}
